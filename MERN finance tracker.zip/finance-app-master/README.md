# Finance Dashboard App

Build A MERN Finance Dashboard App

Video: https://www.youtube.com/watch?v=uoJ0Tv-BFcQ

For all related questions and discussions about this project, check out the discord: https://discord.gg/2FfPeEk2mX
